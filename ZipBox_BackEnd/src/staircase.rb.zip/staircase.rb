def staircase(steps)
  hashes = 1
   until steps == 0 do
      steps.times do
        print " "
      end
      hashes.times do
        print "#"
      end
      print "\n"
    hashes += 1
    steps -= 1
   end
end

staircase(4)
